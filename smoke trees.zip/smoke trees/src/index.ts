import express from 'express'
import { AppDataSource } from "./data-source"
import { User } from "./entity/User"
import { Address } from "./entity/Address"

const app = express()
app.use(express.json())

AppDataSource.initialize()
    .then(() => {
        console.log("Data Source has been initialized!")
    })
    .catch((err) => {
        console.error("Error during Data Source initialization:", err)
    })

app.post('/register', async (req, res) => {
    try {
        const { name, street, city, country } = req.body

        const user = new User()
        user.name = name

        const address = new Address()
        address.street = street
        address.city = city
        address.country = country
        address.user = user

        await AppDataSource.manager.save(user)
        await AppDataSource.manager.save(address)

        res.status(201).json({ message: "User and address registered successfully" })
    } catch (error) {
        console.error(error)
        res.status(500).json({ message: "Error registering user and address" })
    }
})

const PORT = process.env.PORT || 3000
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`)
})